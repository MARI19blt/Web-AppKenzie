# Web App de Sorteio

A Pen created on CodePen.io. Original URL: [https://codepen.io/Mariana-Balta-the-flexboxer/pen/rNqEPqg](https://codepen.io/Mariana-Balta-the-flexboxer/pen/rNqEPqg).

